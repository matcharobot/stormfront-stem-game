'use strict';
const assert = require('node:assert/strict');
const H = require('../src/model.js');
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-7,`${a} != ${b}`);
close(H.runoff(30,1000,.9),27);
close(H.runoff(30,1000,.25),7.5);
close(H.runoff(45,1000,.9)/H.runoff(30,1000,.9),1.5);
const base={baishi:'inlet',qingling:'bypass',confluence:'split',placement:'onpath'};
const reference=H.profiles({});
close(H.sum(reference.plain),92);close(H.sum(reference.hill),108);
for(const baishi of ['store','inlet'])close(H.sum(H.profiles({baishi}).plain),92);
for(const qingling of ['detain','bypass'])close(H.sum(H.profiles({qingling}).hill),108);
assert.deepEqual(H.profiles({qingling:'intercept',placement:'offpath'}).hill,reference.hill);
assert.ok(H.sum(H.profiles({qingling:'intercept'}).hill)<108);
assert.equal(H.canTime({qingling:'intercept',placement:'offpath'}),false);
assert.equal(H.canTime({qingling:'intercept',placement:'onpath'}),true);
assert.equal(H.finalAllowed(base,{},'field'),false);
assert.equal(H.finalAllowed(base,{fieldAgreement:true},'field'),false);
assert.equal(H.finalAllowed(base,{fieldAgreement:true,restorePromise:true},'field'),true);
assert.equal(H.finalAllowed(base,{},'timing'),false);
const endings=new Set();let tested=0;
for(const baishi of ['permeable','store','inlet'])
for(const qingling of ['intercept','detain','bypass'])
for(const confluence of ['source','old','split'])
for(const placement of ['onpath','offpath'])
for(const adjustment of ['none','tanks','timing','field'])
for(const priority of ['balanced','old','corridor']) {
  const c={baishi,qingling,confluence,placement};
  if(!H.finalAllowed(c,{fieldAgreement:true,restorePromise:true},adjustment))continue;
  const s=H.simulate(c,adjustment,priority),low=H.simulate(c,adjustment,priority,'low');
  assert.deepEqual(s,H.simulate(c,adjustment,priority));
  close(s.balanceError,0);
  close(s.total,H.sum(H.profiles(c).plain)+H.sum(H.profiles(c).hill));
  assert.ok(H.sum(low.overflow)<=H.sum(s.overflow)+1e-7);
  assert.ok(s.budget>=0&&s.budget<=12);
  assert.ok(s.field<=64+1e-7);
  assert.ok(s.rows.every(r=>[r.drained,r.oldHeld,r.corridorHeld,r.oldSpill,r.corridorSpill].every(n=>n>=-1e-7)));
  assert.ok(s.rows.every(r=>r.drained<=r.outlet+1e-7&&r.oldHeld<=s.caps[0]+1e-7&&r.corridorHeld<=s.caps[1]+1e-7));
  assert.equal(s.rows.length,10);
  endings.add(s.ending);tested++;
}
assert.deepEqual([...endings].sort(),['both','corridor','delay','field','old']);
const good={baishi:'permeable',qingling:'intercept',confluence:'source',placement:'onpath'};
assert.equal(H.simulate(good).ending,'both');
assert.equal(H.simulate(good,'none','corridor').ending,'corridor');
assert.equal(H.simulate({...good,placement:'offpath'},'none','old').ending,'old');
assert.equal(H.simulate({...good,placement:'offpath',confluence:'old'},'none','corridor').ending,'delay');
assert.equal(H.simulate({...base,qingling:'detain'},'field').ending,'field');
console.log(`PASS: ${tested} complete legal routes; five endings reachable; mass balance, timing, budget and agreement gates verified.`);
