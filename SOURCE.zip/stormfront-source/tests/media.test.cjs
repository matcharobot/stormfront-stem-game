'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const events=[];
class AudioStub{constructor(src){this.src=src;}pause(){events.push(['pause',this.src]);}play(){events.push(['play',this.src,this.volume]);return Promise.resolve();}}
const context={window:{Audio:AudioStub,StormMediaMap:{'answer-correct.wav':'data:audio/wav;base64,CORRECT','answer-incorrect.wav':'data:audio/wav;base64,INCORRECT'}}};
vm.runInNewContext(fs.readFileSync(require.resolve('../src/media.js'),'utf8'),context);
const M=context.window.StormMedia;
assert.equal(M.answer(true),true);assert.equal(M.answer(false),true);
assert.equal(events.filter(x=>x[0]==='play').length,2);
assert.notEqual(events.filter(x=>x[0]==='play')[0][1],events.filter(x=>x[0]==='play')[1][1]);
assert.equal(events.filter(x=>x[0]==='pause').length,1,'a new response stops the previous short sound');
assert.equal(M.answer(true,false),false);assert.equal(events.filter(x=>x[0]==='play').length,2,'disabled feedback never starts playback');
assert.equal(M.asset('drainage-cities.mp4'),'media/drainage-cities.mp4');
assert.ok(events.filter(x=>x[0]==='play').every(x=>x[2]>0&&x[2]<=.35));
const silent={window:{}};vm.runInNewContext(fs.readFileSync(require.resolve('../src/media.js'),'utf8'),silent);assert.equal(silent.window.StormMedia.answer(true),false,'visual feedback remains usable without an audio API');
console.log('PASS: distinct answer audio, single-sound playback, independent mute, safe volume and unavailable-audio fallback.');
