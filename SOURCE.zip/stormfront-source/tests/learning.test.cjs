'use strict';
const assert=require('node:assert/strict');
const H=require('../src/model.js'),L=require('../src/learning.js');
function fixture(){
  const r=L.upgrade({version:3,choices:{baishi:'permeable',qingling:'intercept',placement:'onpath',confluence:'source'},answers:{baishi:'surface',qingling:'travel'},quiz:{},adjustment:'none',priority:'balanced',simChapter:'review'});
  r.sim=H.simulate(r.choices,r.adjustment,r.priority);return r;
}
function complete(r){
  r.council={step:2,mode:'pair',proposal:'We propose upstream interception to reduce the combined runoff before it enters the city.',metric:'peak',challenge:'Could a lower outlet capacity still overload the proposed district storage during the storm?',agreement:'Keep the proposal and recheck the outlet under current river conditions.',approvedFor:L.designKey(r)};
  for(const q of L.questions)r.quiz[q.id]=q.correct;
  r.answers.path='connected';r.reportMetric='inflow';
  r.explanation='Permeable paving and upstream interception reduce the inflow reaching the constrained outlet and protect both districts.';
  r.followup='Keep the remaining credits for later maintenance and inspection.';
  r.reportAcceptedFor=L.testKey(r);return r;
}
let r=fixture();assert.equal(r.sim.ending,'both');assert.equal(L.canComplete(r),false,'a hydraulic pass must not complete learning');
complete(r);assert.equal(L.canComplete(r),true);assert.equal(L.caseClosed(r),false,'closing needs an explicit final action');
r.learningClosedFor=L.testKey(r);assert.equal(L.caseClosed(r),true);
const copy=x=>JSON.parse(JSON.stringify(x));
for(const q of L.questions){const x=copy(r);x.quiz[q.id]=(q.correct+1)%3;assert.equal(L.canComplete(x),false);assert.equal(L.firstMissingQuestion(x),L.questions.indexOf(q));}
for(const field of ['proposal','challenge','agreement']){const x=copy(r);x.council[field]='too short';assert.equal(L.councilComplete(x),false);assert.equal(L.canComplete(x),false);}
for(const mode of ['solo','pair']){const x=copy(r);x.council.mode=mode;assert.equal(L.councilComplete(x),true);}
const changed=copy(r);changed.choices.confluence='split';assert.equal(L.councilComplete(changed),false,'a changed design needs a new council decision');assert.equal(L.reportComplete(changed),false);
for(const field of ['explanation','followup']){const x=copy(r);x[field]=' ';assert.equal(L.reportComplete(x),false);}
for(const key of ['path','metric']){const x=copy(r);if(key==='path')x.answers.path='local';else x.reportMetric='';assert.equal(L.reportDraftReady(x),false);}
const allocation=copy(r);allocation.priority='old';allocation.sim=H.simulate(allocation.choices,allocation.adjustment,allocation.priority);assert.equal(L.reportComplete(allocation),false,'old reasoning must be reconfirmed for a changed test');
const low=copy(r);low.sim=H.simulate(low.choices,low.adjustment,low.priority,'low');assert.equal(L.canComplete(low),false,'the final decision must use the high-river test');
const wrongProcess=copy(r);wrongProcess.answers.baishi='rain';assert.equal(L.canComplete(wrongProcess),false);
const delayed=fixture();delayed.choices={baishi:'inlet',qingling:'bypass',placement:'offpath',confluence:'split'};delayed.sim=H.simulate(delayed.choices);assert.equal(delayed.sim.ending,'delay');complete(delayed);assert.equal(L.canComplete(delayed),true,'a postponed opening can still have a complete learning record');
const legacy={version:2,choices:r.choices,quiz:{control:0,travel:0,storage:2,transfer:0},explanation:'Existing text stays.',priority:'balanced'};L.upgrade(legacy);assert.equal(legacy.version,3);assert.equal(legacy.explanation,'Existing text stays.');assert.equal(legacy.reviewStep,'summary');assert.equal(legacy.quizIndex,1);assert.equal(L.canComplete(legacy),false);
const guided=complete(fixture());
assert.equal(L.reviewGuide(guided).next.action,'complete-case');assert.equal(L.reviewGuide(guided).count,3);
guided.answers.baishi='rain';assert.equal(L.reviewGuide(guided).next.id,'baishi','three complete records must not hide an unsupported earlier explanation');
guided.answers.baishi='surface';guided.answers.qingling='stop';assert.equal(L.reviewGuide(guided).next.id,'qingling');guided.answers.qingling='travel';
guided.council.challenge='';assert.equal(L.reviewGuide(guided).next.key,'council');assert.equal(L.nextCouncilStep(guided),1,'resume at the missing role contribution');
guided.council.challenge='Would the selected peak overload the outlet if the river rises?';guided.council.approvedFor=L.designKey(guided);guided.quiz.travel=0;assert.equal(L.reviewGuide(guided).next.key,'quiz');
guided.quiz.travel=1;guided.followup='';assert.equal(L.reviewGuide(guided).next.key,'report');assert.equal(L.reviewGuide(guided).count,2);
guided.followup='Reserve the remaining credits for later maintenance and inspection.';guided.reportAcceptedFor=null;assert.equal(L.reviewGuide(guided).next.key,'report','a retained draft still needs recording for the current test');
guided.reportAcceptedFor=L.testKey(guided);assert.equal(L.reviewGuide(guided).next.key,'close');guided.sim=null;assert.equal(L.reviewGuide(guided).next.key,'test','no statement can substitute for a current high-river test');
console.log('PASS: learning completion, wrong-answer gates, role records, report completeness, stale evidence, independent engineering outcomes, and legacy-save migration.');
