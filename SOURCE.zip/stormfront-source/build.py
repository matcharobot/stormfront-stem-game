"""Compile the local Twine HTML using the official, vendored SugarCube template."""
import html
import json
from pathlib import Path
import re
import shutil
import base64
import mimetypes

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'dist'
OUT.mkdir(exist_ok=True)
fmt = (ROOT / 'vendor/format.js').read_text()
fmt = json.loads(fmt[fmt.index('(')+1:fmt.rindex(')')])
story = (ROOT / 'story.twee').read_text()
parts = re.split(r'^:: ([^\n]+)\n', story, flags=re.M)
passages = []
for header, text in zip(parts[1::2], parts[2::2]):
    title = header.split(' {')[0].strip()
    if title in ('StoryTitle', 'StoryData'):
        continue
    pos = re.search(r'"position":"([^"]+)"', header)
    passages.append((title, text.strip(), pos.group(1) if pos else '100,100'))
css = (ROOT / 'src/style.css').read_text()
js = '\n'.join((ROOT / 'src' / f).read_text() for f in ('model.js', 'data.js', 'learning.js', 'media.js', 'app.js'))
data = '<tw-storydata name="Stormfront: The Three-City Drainage Case" startnode="1" creator="Stormfront Local Compiler" creator-version="1.0" ifid="934C23F0-131A-4ABA-A62A-E900303CD065" format="SugarCube" format-version="2.37.3" options="" hidden>'
data += '<style role="stylesheet" id="twine-user-stylesheet" type="text/twine-css">'+css+'</style>'
data += '<script role="script" id="twine-user-script" type="text/twine-javascript">'+js+'</script>'
for i, (title, text, pos) in enumerate(passages, 1):
    data += f'<tw-passagedata pid="{i}" name="{html.escape(title)}" tags="" position="{pos}" size="100,100">{html.escape(text)}</tw-passagedata>'
data += '</tw-storydata>'
compiled = fmt['source'].replace('{{STORY_NAME}}', 'Stormfront: The Three-City Drainage Case').replace('{{STORY_DATA}}', data)
compiled = compiled.replace('<html', '<html lang="en"', 1)
compiled = compiled.replace('</head>', '<meta name="description" content="Investigate three cities, test drainage designs, and explain your engineering trade-offs."><meta name="theme-color" content="#f3f0e7"></head>', 1)
(OUT / 'index.html').write_text(compiled)
(OUT / '.nojekyll').touch()
assets = ROOT.parent / 'outputs/stormfront-assets-v2/assets'
if not assets.is_dir():
    assets = OUT / 'assets'
if assets.resolve() != (OUT / 'assets').resolve():
    shutil.copytree(assets, OUT / 'assets', dirs_exist_ok=True)
shutil.copy2(ROOT / 'vendor/LICENSE', OUT / 'SUGARCUBE-LICENSE.txt')
asset_map = {str(p.relative_to(assets).with_suffix('')): 'data:image/webp;base64,'+base64.b64encode(p.read_bytes()).decode() for p in assets.rglob('*.webp')}
media = ROOT / 'media'
shutil.copytree(media, OUT / 'media', dirs_exist_ok=True)
media_map = {p.name: 'data:'+(mimetypes.guess_type(p.name)[0] or 'application/octet-stream')+';base64,'+base64.b64encode(p.read_bytes()).decode() for p in media.iterdir() if p.is_file()}
standalone = compiled.replace(js, 'window.StormAssetMap='+json.dumps(asset_map)+';\nwindow.StormMediaMap='+json.dumps(media_map)+';\n'+js, 1)
review_path = ROOT.parent / 'outputs/Stormfront-Local-Review.html'
review_path.parent.mkdir(parents=True, exist_ok=True)
review_path.write_text(standalone)
full_twee = story + '\n\n:: StoryStylesheet [stylesheet]\n' + css + '\n\n:: StoryScript [script]\n' + js
(ROOT / 'Stormfront.twee').write_text(full_twee)
print(f'Built {OUT / "index.html"}: {len(passages)} Twine passages, 18 WebP assets; no external runtime requests.')
print(f'Self-contained local review: {review_path}')
