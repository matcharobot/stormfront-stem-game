"""Render the teaching video, matched English narration and answer tones.

Requires Pillow and FFmpeg (set FFMPEG or install imageio-ffmpeg).
On macOS use --synthesize-to DIR to record the six lines with the system voice,
then use --narration-dir DIR to render. Other platforms can supply six matching
PCM files named 01.aiff through 06.aiff.
"""
import argparse
from array import array
from dataclasses import dataclass
import math
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import wave

from PIL import Image, ImageDraw, ImageFont, ImageOps

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'media'
ASSETS = ROOT / 'dist/assets'
WIDTH, HEIGHT, FPS = 960, 540, 20
SCENE_SECONDS = 7
SAMPLE_RATE = 44100
PAPER, INK, TEAL, LINE = '#f3f0e6', '#273c3e', '#2d7273', '#c4d0b8'
BLUE, AMBER = '#25859b', '#a47743'
BOARD = (32, 116, 620, 398)
SIZE = (588, 282)


@dataclass(frozen=True)
class Scene:
    title: str
    topic: str
    takeaway: str
    detail: str
    narration: str
    art: str | None = None


SCENES = (
    Scene('Why cities need drainage', 'RUNOFF', 'Follow the rain',
          'Rain runs off roofs and paved surfaces. The drainage system collects it.',
          'Rainwater runs off roofs and streets. Urban drainage collects and manages this runoff.',
          'cover/cover.webp'),
    Scene('Collect and convey', 'CONVEYANCE', 'From street to drain',
          'Street inlets collect runoff. Channels and pipes carry it onward.',
          'Street drains collect runoff. Channels and pipes carry it away from places people use.',
          'maps/01-baishi-plaza.webp'),
    Scene('Slow and store', 'STORAGE', 'Give water time',
          'Soil can absorb water. Temporary storage holds it for later release.',
          'Permeable ground lets water soak in. Storage holds runoff and releases it later.',
          'maps/03-huiwan-confluence.webp'),
    Scene('Protect daily life', 'CITY LIFE', 'Keep places accessible',
          'Reducing flood risk supports homes, shops and routes people depend on.',
          'Managing runoff helps protect homes, shops and transport routes from flooding.',
          'endings/both-open.webp'),
    Scene('Understand the limits', 'OUTLET CAPACITY', 'Check the river level',
          'That same outlet can carry less water when the river is high.',
          'A high river can slow discharge from the same outlet, even after a pipe upgrade.'),
    Scene('Your catchment investigation', 'YOUR MISSION', 'Follow. Compare. Test.',
          'Use evidence from all three cities to test a design for the catchment.',
          'Follow the water through three cities. Compare the evidence and test your design.'),
)
DURATION = len(SCENES) * SCENE_SECONDS
FONT_DIR = Path('/System/Library/Fonts/Supplemental')


def font(name, size):
    path = FONT_DIR / name
    if not path.exists():
        path = Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
    return ImageFont.truetype(str(path), size)


LABEL = font('Arial.ttf', 15)
SMALL_LABEL = font('Arial Bold.ttf', 12)
BODY = font('Arial.ttf', 20)
CAPTION = font('Arial.ttf', 21)
BOLD = font('Arial Bold.ttf', 23)
TITLE = font('Georgia.ttf', 35)


def wrap(draw, text, face, width):
    lines = []
    current = ''
    for word in text.split():
        candidate = f'{current} {word}'.strip()
        if current and draw.textlength(candidate, font=face) > width:
            lines.append(current)
            current = word
        else:
            current = candidate
    return lines + [current]


def badge(draw, xy, label, background='#f8f6eb', foreground=INK):
    x, y = xy
    w = draw.textlength(label, font=SMALL_LABEL) + 16
    draw.rounded_rectangle((x, y, x + w, y + 23), radius=4, fill=background)
    draw.text((x + 8, y + 4), label, font=SMALL_LABEL, fill=foreground)


def arrow(draw, start, end, color=TEAL, width=4):
    draw.line((start, end), fill=color, width=width)
    angle = math.atan2(end[1]-start[1], end[0]-start[0])
    corners = [(end[0]-10*math.cos(angle+d), end[1]-10*math.sin(angle+d))
               for d in (-.55, .55)]
    draw.polygon([end, *corners], fill=color)


def rainfall(draw, elapsed):
    for column in range(23):
        x = 17 + column * 25
        y = 6 + (column * 37 + elapsed * 93) % 108
        draw.line((x, y, x-5, y+13), fill=(27, 109, 131, 165), width=2)
    for x, y in ((77, 184), (293, 184), (482, 218)):
        radius = 3 + 9*((elapsed*1.15 + x/150) % 1)
        draw.ellipse((x-radius, y-radius/3, x+radius, y+radius/3),
                     outline=(27, 105, 130, 195), width=2)


def conveyance(draw, elapsed):
    # The grate sits in the street between the plaza and the lawn.
    draw.rounded_rectangle((278, 190, 296, 221), radius=2, fill=INK)
    for y in range(193, 221, 5):
        draw.line((281, y, 293, y), fill='#d5e6df', width=1)
    phase = (elapsed * .8) % 1
    for start in ((239, 148), (338, 175), (288, 245)):
        end = (288, 205)
        arrow(draw, start, end, '#286a79', width=3)
        x, y = [a+(b-a)*phase for a, b in zip(start, end)]
        draw.ellipse((x-4, y-4, x+4, y+4), fill='#e7f6f4', outline=TEAL)
    badge(draw, (222, 112), 'STREET INLET')


def storage(draw, elapsed):
    # Inset cross-section shows the direction of infiltration and later release.
    draw.rounded_rectangle((16, 135, 333, 268), radius=5, fill='#f8f6eb', outline=TEAL)
    badge(draw, (26, 144), 'SOAK IN', '#dde7d6')
    draw.rectangle((28, 208, 146, 250), fill='#bda988')
    draw.line((28, 205, 146, 205), fill='#688867', width=6)
    for x in (54, 87, 120):
        y = 213 + 17*((elapsed*.8) % 1)
        arrow(draw, (x, y-11), (x, y+8), BLUE, width=3)
    badge(draw, (172, 144), 'STORE & RELEASE', '#dde8e3')
    draw.rounded_rectangle((176, 194, 267, 251), radius=3, outline=TEAL, width=2)
    progress = elapsed / SCENE_SECONDS
    level = 8 + 39*(progress/.55 if progress <= .55 else (1-progress)/.45)
    draw.rectangle((179, 248-level, 264, 248), fill='#6fb6c3')
    if progress <= .55:
        arrow(draw, (221, 177), (221, 202), BLUE, width=3)
    else:
        arrow(draw, (268, 241), (302, 241), BLUE, width=3)


def city_life(draw, elapsed):
    points = ((73, 49, 50, 16, 'HOMES'),
              (119, 173, 55, 109, 'SHOPS'),
              (365, 196, 404, 145, 'WALKING ROUTE'))
    for i, (x, y, bx, by, title) in enumerate(points):
        if elapsed >= i * 1.2:
            draw.line((x, y, bx+10, by+22), fill='#f8f6eb', width=3)
            draw.ellipse((x-5, y-5, x+5, y+5), fill=TEAL, outline='#f8f6eb', width=2)
            badge(draw, (bx, by), title)


def outlet_scene(draw, elapsed):
    for i, label in enumerate(('LOW RIVER', 'HIGH RIVER')):
        x = 14 + 287*i
        draw.rounded_rectangle((x, 14, x+273, 268), radius=5,
                               fill='#faf8ef', outline=LINE)
        badge(draw, (x+13, 24), label, '#dde8e3')
        draw.rectangle((x+12, 82, x+139, 193), fill='#d6cbb3')
        draw.rectangle((x+12, 122, x+164, 146), fill='#fbf9f2', outline=INK, width=2)
        level = 158 if i == 0 else 114
        draw.rectangle((x+141, level, x+260, 193), fill='#8fc0c7')
        draw.line((x+141, level, x+260, level), fill=BLUE, width=2)
        arrow(draw, (x+50, 134), (x+218 if i == 0 else x+173, 134),
              TEAL if i == 0 else AMBER, width=4)
        dot = x + 48 + ((elapsed * (55 if i == 0 else 22)) % (147 if i == 0 else 104))
        draw.ellipse((dot-4, 130, dot+4, 138), fill='#fffef1')
        draw.text((x+13, 213), '32 m³ / round' if i == 0 else '16 m³ / round',
                  font=BOLD, fill=INK)
        draw.text((x+13, 242), 'Example from the game', font=LABEL, fill=TEAL)


def mission_scene(image, elapsed, thumbnails):
    draw = ImageDraw.Draw(image)
    active = min(2, int(elapsed / (SCENE_SECONDS / 3)))
    for i, (title, action) in enumerate((('Baishi', 'Compare surfaces'),
                                         ('Qingling', 'Trace the runoff'),
                                         ('Huiwan', 'Test the system'))):
        x = 10 + 192*i
        color = TEAL if i == active else LINE
        draw.rounded_rectangle((x, 29, x+183, 253), radius=5,
                               fill='#faf8ef', outline=color, width=3 if i == active else 1)
        image.paste(thumbnails[i], (x+7, 38))
        draw.text((x+12, 174), title, font=BOLD, fill=INK)
        draw.text((x+12, 213), action, font=LABEL, fill=TEAL)


ANIMATIONS = (rainfall, conveyance, storage, city_life, outlet_scene)


def create_renderer():
    photos = [ImageOps.fit(Image.open(ASSETS / scene.art).convert('RGB'), SIZE)
              if scene.art else Image.new('RGB', SIZE, '#e9eee2')
              for scene in SCENES]
    thumbnails = [ImageOps.fit(Image.open(ASSETS / 'maps' / file).convert('RGB'), (170, 122))
                  for file in ('01-baishi-plaza.webp', '02-qingling-slope.webp', '04-huiwan-downtown.webp')]

    def frame(time):
        index = min(len(SCENES)-1, int(time // SCENE_SECONDS))
        elapsed = time - index*SCENE_SECONDS
        scene = SCENES[index]
        image = Image.new('RGB', (WIDTH, HEIGHT), PAPER)
        draw = ImageDraw.Draw(image)
        draw.text((32, 23), 'STORMFRONT  /  FIELD BRIEFING', font=LABEL, fill=TEAL)
        draw.text((928, 23), f'{index+1:02d} / {len(SCENES):02d}', font=LABEL, fill=TEAL, anchor='ra')
        draw.text((32, 61), scene.title, font=TITLE, fill=INK)

        art = photos[index].copy()
        if index < len(ANIMATIONS):
            ANIMATIONS[index](ImageDraw.Draw(art, 'RGBA'), elapsed)
        else:
            mission_scene(art, elapsed, thumbnails)
        image.paste(art, BOARD[:2])
        draw.rounded_rectangle(BOARD, radius=3, outline=LINE)
        draw.rounded_rectangle((646, 116, 928, 398), radius=4, fill='#fbf9f1', outline=LINE)
        draw.text((666, 133), scene.topic, font=LABEL, fill=TEAL)
        y = 170
        for line in wrap(draw, scene.takeaway, BOLD, 240):
            draw.text((666, y), line, font=BOLD, fill=INK)
            y += 29
        y += 17
        for line in wrap(draw, scene.detail, BODY, 240):
            draw.text((666, y), line, font=BODY, fill='#52684f')
            y += 27

        captions = wrap(draw, scene.narration, CAPTION, 848)
        draw.rounded_rectangle((32, 408, 928, 466), radius=4, fill=INK)
        for i, line in enumerate(captions):
            y = (437 if len(captions) == 1 else 424) + i*25
            draw.text((480, y), line, font=CAPTION, fill='#fffef2', anchor='mm')
        return image

    return frame


def synthesize(directory):
    directory.mkdir(parents=True, exist_ok=True)
    for index, scene in enumerate(SCENES, 1):
        path = directory / f'{index:02d}.aiff'
        subprocess.run(['say', '-v', 'Samantha', '-r', '164', '-o', str(path),
                        scene.narration], check=True)
        if path.stat().st_size <= 4096:
            raise RuntimeError(f'Voice synthesis did not produce speech for scene {index}.')


def get_ffmpeg():
    command = os.environ.get('FFMPEG') or shutil.which('ffmpeg')
    if command:
        return command
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()


def narration_track(ffmpeg, directory, output):
    lead = int(.25 * SAMPLE_RATE)
    scene_length = SCENE_SECONDS * SAMPLE_RATE
    with wave.open(str(output), 'wb') as result:
        result.setparams((1, 2, SAMPLE_RATE, 0, 'NONE', 'not compressed'))
        for index in range(1, len(SCENES)+1):
            pcm = subprocess.check_output([
                ffmpeg, '-v', 'error', '-i', str(directory / f'{index:02d}.aiff'),
                '-ac', '1', '-ar', str(SAMPLE_RATE), '-f', 's16le', '-',
            ])
            samples = array('h', pcm)
            peak = max(map(abs, samples), default=0)
            tail = scene_length - lead - len(samples)
            if len(samples) < SAMPLE_RATE or peak < 300 or tail < int(.12 * SAMPLE_RATE):
                raise ValueError(f'Narration for scene {index} is silent or does not fit its caption.')
            gain = min(3, .78*32767/peak)
            result.writeframes(bytes(2*lead))
            result.writeframes(array('h', (round(s*gain) for s in samples)).tobytes())
            result.writeframes(bytes(2*tail))
            print(f'Scene {index}: {len(samples)/SAMPLE_RATE:.2f}s narration', flush=True)


def write_answer_tones():
    for name, notes, duration in (
        ('correct', [(0, 659.25, .14), (.13, 880, .20)], .40),
        ('incorrect', [(0, 220, .14), (.16, 164.81, .13)], .36),
    ):
        path = OUT / f'answer-{name}.wav'
        if path.exists():
            continue
        samples = array('h')
        for i in range(int(SAMPLE_RATE * duration)):
            time = i/SAMPLE_RATE
            value = 0
            for start, hz, length in notes:
                q = time - start
                if 0 <= q < length:
                    envelope = min(1, q/.012) * (1-q/length)**1.6
                    value += (math.sin(2*math.pi*hz*q) + .12*math.sin(6*math.pi*hz*q))*.26*envelope
            samples.append(int(value*32767))
        with wave.open(str(path), 'wb') as sound:
            sound.setparams((1, 2, SAMPLE_RATE, 0, 'NONE', 'not compressed'))
            sound.writeframes(samples.tobytes())


def render(narration_dir, review_dir=None):
    ffmpeg = get_ffmpeg()
    frame = create_renderer()
    OUT.mkdir(exist_ok=True)
    if review_dir:
        review_dir.mkdir(parents=True, exist_ok=True)
        for i in range(len(SCENES)):
            frame(i*SCENE_SECONDS+4.8).save(review_dir / f'scene-{i+1:02d}.jpg', quality=92)
    with tempfile.TemporaryDirectory(prefix='stormfront-media-') as tmp:
        wav = Path(tmp) / 'voice.wav'
        video = Path(tmp) / 'drainage.mp4'
        narration_track(ffmpeg, narration_dir, wav)
        cmd = [ffmpeg, '-v', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24',
               '-s', f'{WIDTH}x{HEIGHT}', '-r', str(FPS), '-i', '-', '-i', str(wav),
               '-c:v', 'libx264', '-preset', 'medium', '-crf', '21', '-pix_fmt', 'yuv420p',
               '-c:a', 'aac', '-b:a', '96k', '-movflags', '+faststart', str(video)]
        with subprocess.Popen(cmd, stdin=subprocess.PIPE) as process:
            try:
                for i in range(FPS * DURATION):
                    process.stdin.write(frame(i/FPS).tobytes())
            finally:
                process.stdin.close()
            if process.wait():
                raise RuntimeError('FFmpeg could not encode the teaching video.')
        shutil.copyfile(video, OUT / 'drainage-cities.mp4')
    frame(1.3).save(OUT / 'drainage-poster.webp', quality=90)
    write_answer_tones()
    script = '\n\n'.join(
        f'{i*SCENE_SECONDS:02d}–{(i+1)*SCENE_SECONDS:02d} seconds / {scene.title}\n{scene.narration}'
        for i, scene in enumerate(SCENES))
    (OUT / 'drainage-transcript.txt').write_text(
        f'WHY CITIES NEED DRAINAGE\nIllustrated teaching video / {DURATION} seconds\n\n'
        f'{script}\n\nNarration: macOS Samantha English system voice. '
        'Illustrations: Recraft. Content reference: US EPA, About Green Infrastructure, '
        'https://www.epa.gov/green-infrastructure/about-green-infrastructure\n', encoding='utf-8')
    print(f'Created narrated {DURATION}-second teaching video and poster.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--synthesize-to', type=Path)
    mode.add_argument('--narration-dir', type=Path)
    parser.add_argument('--review-dir', type=Path)
    args = parser.parse_args()
    if args.synthesize_to:
        synthesize(args.synthesize_to)
    else:
        render(args.narration_dir, args.review_dir)
