"""Create the original captioned teaching video and short answer tones.
Requires Pillow and an ffmpeg executable (set FFMPEG or install imageio-ffmpeg).
"""
from pathlib import Path
import math, os, random, shutil, struct, subprocess, sys, textwrap, wave
from PIL import Image, ImageDraw, ImageFont, ImageOps
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'media'; OUT.mkdir(exist_ok=True)
FFMPEG=os.environ.get('FFMPEG') or shutil.which('ffmpeg')
if not FFMPEG:
 import imageio_ffmpeg
 FFMPEG=imageio_ffmpeg.get_ffmpeg_exe()
W,H,FPS,SECONDS=960,540,20,42
PAPER='#f3f0e6'; INK='#273c3e'; TEAL='#2d7273'; LINE='#c4d0b8'
fonts=Path('/System/Library/Fonts/Supplemental')
def font(name,size):
 path=fonts/name
 if not path.exists():
  path=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
 return ImageFont.truetype(str(path),size)
F={s:font('Arial.ttf',s) for s in [13,15,17,20,21,23,27]}; FB=font('Arial Bold.ttf',23); TITLE=font('Georgia.ttf',35)
scenes=[
 ('Why cities need drainage','Follow the rain','Rainwater becomes runoff on roofs, streets and squares.','Urban drainage manages rainwater from roofs, streets and squares.','cover/cover.webp'),
 ('Collect and convey','Move water carefully','Drains, channels and pipes guide runoff through the city.','Drains, channels and pipes carry runoff away from places people use.','maps/01-baishi-plaza.webp'),
 ('Slow and store','Give water time','Permeable ground and storage reduce pressure on the network.','Permeable ground and storage can reduce runoff or hold it for later release.','maps/03-huiwan-confluence.webp'),
 ('Protect daily life','Keep the city connected','Stormwater management helps protect homes, shops and transport access.','Managing stormwater helps protect homes, shops and transport routes.','maps/04-huiwan-downtown.webp'),
 ('Understand the limits','Think beyond one pipe','Intense rain and downstream conditions can exceed drainage capacity.','Drainage has limits. Rainfall, flow timing, storage and river conditions must be considered together.','maps/02-qingling-slope.webp'),
 ('Your catchment investigation','Follow. Compare. Test.','Use evidence to explain how one decision affects the wider system.','Follow the water, compare evidence and test a design for the whole catchment.','cover/cover.webp')]
assets=ROOT/'dist/assets'
photos=[ImageOps.fit(Image.open(assets/s[4]).convert('RGB'),(588,302)) for s in scenes]
def lines(d,text,f,width):
 words=text.split(); result=[]; current=''
 for word in words:
  test=(current+' '+word).strip()
  if d.textlength(test,font=f)>width and current:result.append(current);current=word
  else:current=test
 if current:result.append(current)
 return result
paths=[[(77,204),(220,243),(350,300),(590,354)],[(83,330),(220,290),(410,318),(588,374)]]
def along(points,p):
 lengths=[math.dist(a,b) for a,b in zip(points,points[1:])];target=p*sum(lengths)
 for (a,b),length in zip(zip(points,points[1:]),lengths):
  if target<=length:
   k=target/length;return (a[0]+(b[0]-a[0])*k,a[1]+(b[1]-a[1])*k)
  target-=length
 return points[-1]
def frame(t):
 idx=min(5,int(t//7));u=(t%7)/7
 im=Image.new('RGB',(W,H),PAPER);d=ImageDraw.Draw(im)
 d.text((32,23),'STORMFRONT  /  FIELD BRIEFING',font=F[15],fill=TEAL)
 d.text((928,23),f'{idx+1:02d} / 06',font=F[15],fill=TEAL,anchor='ra')
 d.text((32,60),scenes[idx][0],font=TITLE,fill=INK)
 im.paste(photos[idx],(32,124));d.rounded_rectangle((32,124,620,426),radius=3,outline=LINE,width=1)
 # Continuously moving water makes this a time-based teaching animation.
 overlay=Image.new('RGBA',(W,H));o=ImageDraw.Draw(overlay)
 if idx==0:
  for k in range(34):
   x=46+(k*67)%558;y=136+((t*70+k*31)%272)
   o.line((x,y,x-4,y+12),fill=(49,127,150,120),width=2)
 for j,path in enumerate(paths):
  o.line(path,fill=(45,114,130,135),width=3,joint='curve')
  for k in range(8):
   p=(u*(.75 if idx==2 else 1.6)+k/8+j*.06)%1
   x,y=along(path,p);o.ellipse((x-4,y-4,x+4,y+4),fill=(46,137,165,205))
 if idx==2:
  o.rounded_rectangle((385,330,479,406),radius=4,fill=(243,240,230,235),outline=(45,114,115,255),width=3)
  level=12+42*(.5+.5*math.sin(t*.8));o.rectangle((389,402-level,475,402),fill=(78,151,170,175))
 if idx==3:
  for x,y in [(175,245),(365,210),(510,340)]:
   r=18+3*math.sin(t*2);o.ellipse((x-r,y-r,x+r,y+r),outline=(76,139,102,230),width=4)
 if idx==4:
  o.line((526,165,580,165),fill=(177,121,57,255),width=5)
  for k in range(4):
   y=190+k*30;o.ellipse((544-6,y-6,544+6,y+6),fill=(177,121,57,170))
 im=Image.alpha_composite(im.convert('RGBA'),overlay).convert('RGB');d=ImageDraw.Draw(im)
 d.rounded_rectangle((646,124,928,426),radius=4,fill='#fbf9f1',outline=LINE,width=1)
 d.text((666,143),['RUNOFF','CONVEYANCE','STORAGE','CITY LIFE','CAPACITY','YOUR MISSION'][idx],font=F[13],fill=TEAL)
 y=177
 for line in lines(d,scenes[idx][1],FB,240):d.text((666,y),line,font=FB,fill=INK);y+=29
 y+=17
 for line in lines(d,scenes[idx][2],F[20],240):d.text((666,y),line,font=F[20],fill='#62775e');y+=28
 d.text((666,386),'Illustrated teaching animation',font=F[13],fill='#718466')
 d.rounded_rectangle((32,442,928,494),radius=3,fill=INK)
 cap=lines(d,scenes[idx][3],F[20],858);y=451 if len(cap)>1 else 457
 for line in cap:d.text((480,y),line,font=F[20],fill='#fffef2',anchor='ma');y+=24
 d.line((32,522,928,522),fill=LINE,width=3);d.line((32,522,32+896*t/SECONDS,522),fill=TEAL,width=3)
 return im
poster=frame(1.3);poster.save(OUT/'drainage-poster.webp',quality=90)
# Low-level ambient soundtrack; instruction is available in burned-in English captions.
random.seed(7220);sr=44100; samples=bytearray();v=0.0
for i in range(SECONDS*sr):
 v=(v+.035*(random.random()*2-1))/1.035
 envelope=min(1,i/sr,max(0,(SECONDS*sr-i)/sr));sample=int(max(-1,min(1,v*.7*envelope))*32767)
 samples.extend(struct.pack('<h',sample))
with wave.open(str(OUT/'video-ambience.wav'),'wb') as w:w.setparams((1,2,sr,0,'NONE','not compressed'));w.writeframes(samples)
cmd=[FFMPEG,'-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-i',str(OUT/'video-ambience.wav'),'-c:v','libx264','-preset','medium','-crf','25','-pix_fmt','yuv420p','-c:a','aac','-b:a','64k','-movflags','+faststart','-shortest',str(OUT/'drainage-cities.mp4')]
proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=subprocess.PIPE)
for i in range(FPS*SECONDS):proc.stdin.write(frame(i/FPS).tobytes())
proc.stdin.close();errors=proc.stderr.read();assert proc.wait()==0,errors.decode()
# Quiet, short, distinct feedback tones; no external sound assets.
for correct,notes,duration in [(True,[(0,659.25,.14),(.13,880,.20)],.40),(False,[(0,220,.14),(.16,164.81,.13)],.36)]:
 data=bytearray()
 for i in range(int(sr*duration)):
  t=i/sr;s=0
  for start,hz,length in notes:
   q=t-start
   if 0<=q<length:
    env=min(1,q/.012)*max(0,1-q/length)**1.6
    s+=(math.sin(2*math.pi*hz*q)+.12*math.sin(2*math.pi*hz*3*q))*.26*env
  data.extend(struct.pack('<h',int(max(-1,min(1,s))*32767)))
 with wave.open(str(OUT/('answer-correct.wav' if correct else 'answer-incorrect.wav')),'wb') as w:w.setparams((1,2,sr,0,'NONE','not compressed'));w.writeframes(data)
(OUT/'drainage-transcript.txt').write_text('WHY CITIES NEED DRAINAGE\nOriginal illustrated teaching animation / 42 seconds\n\n'+'\n\n'.join(f'{i*7:02d}–{(i+1)*7:02d} seconds / {s[0]}\n{s[3]}' for i,s in enumerate(scenes))+'\n\nVisuals: existing project illustrations generated and edited with Recraft; animated teaching overlays. Ambient audio and answer tones: programmatically synthesized.\nContent reference: US EPA, About Green Infrastructure, https://www.epa.gov/green-infrastructure/about-green-infrastructure\n')
# Keep only the compressed soundtrack in the public movie; do not package the intermediate WAV.
(OUT/'video-ambience.wav').unlink()
print('Created 42-second H.264/AAC video, poster, transcript and two answer tones.')
print('MP4 bytes:',(OUT/'drainage-cities.mp4').stat().st_size)
