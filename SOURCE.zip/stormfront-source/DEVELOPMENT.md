# Development and Teaching Notes

An English, fixed 16:9 educational game built with Twine / SugarCube 2.37.3. The game is packaged for static hosting and offline review.

## Play locally

Open `../outputs/Stormfront-Local-Review.html` in Chrome, Edge or Safari. This self-contained file embeds all 18 illustrations and the story runtime. It needs no installation, server or network connection. Use the buttons to move between screens; there is no scrolling page. A non-16:9 window adds letterboxing while preserving the game frame. A landscape display is recommended. The game has no separate header or footer; journal, rain and course controls float inside the scene, as do navigation buttons. About the Course remains one page, with objectives, concrete SBL and 5E applications, and a Recraft image credit at the bottom.

The `dist/index.html` version uses separate WebP and media files. Keep its `assets` and `media` folders beside the HTML. It supports static hosting under a GitHub Pages project path. The self-contained review/publication HTML embeds these files, including the teaching video and answer sounds.

## Structure

- `src/model.js`: deterministic ten-round teaching model and water balance.
- `src/data.js`: English narrative, location anchors, evidence and ending definitions.
- `src/learning.js`: learning completion rules, saved-state migration and review signatures.
- `src/media.js`: video/audio asset resolution and independent correct/incorrect feedback playback.
- `media/`: 42-second teaching MP4, poster, transcript and two original feedback WAV files.
- `tools/make_media.py`: reproducible illustration animation and tone generator (Pillow and FFmpeg needed only to regenerate media).
- `src/app.js`: screen transitions, persistent choices, experiments, negotiation gates, assessment and report export.
- `src/style.css`: 1440 × 810 stage, proportionally scaled to the window.
- `story.twee`: passage scaffold.
- `Stormfront.twee`: generated full Twee source, including story script and stylesheet.
- `vendor/format.js`: official SugarCube 2.37.3 runtime template; see `vendor/LICENSE`.
- `dist/`: complete static web build, including `.nojekyll`.
- `tests/model.test.cjs`: 576 legal route combinations and focused invariant checks.
- `tests/learning.test.cjs`: feedback gates, role contributions, report completeness and save migration.
- `tests/controller.test.cjs`: actual app navigation, completion gates and report export.
- `tests/media.test.cjs`: answer-sound selection, mute, interruption and safe playback fallback.

The compiled `dist/index.html` can also be imported into Twine. It preserves named passages, the story stylesheet and story JavaScript. Screen-level branching uses SugarCube state and events rather than separate empty passages for every combination.

## Rebuild and check

Use Python 3 and Node.js. No package installation is necessary.

```sh
python3 game/build.py
node game/tests/model.test.cjs
node game/tests/learning.test.cjs
node game/tests/controller.test.cjs
node game/tests/media.test.cjs
node --check game/src/app.js
```

Run from the task workspace. `build.py` uses `outputs/stormfront-assets-v2/assets` when available, or the packaged `dist/assets` when rebuilding an extracted source archive. It emits `dist`, a full Twee source and the standalone review file. In an extracted archive, use `python3 build.py` and `node tests/<test-file>.cjs` from its root.

## Teaching design

Learners investigate a rising watermark across Baishi, Qingling and Huiwan. A surface comparison, a delayed-flow explanation, shared-budget choices and a high-river-level retest align with four measurable objectives in the game's single About page. Scenario-Based Learning uses persistent choices and their consequences. The 5E framework connects hypothesis, exploration, explanation, transfer and evaluation; the About page maps each phase to a concrete game activity.

Before travelling from the city fringe, learners complete a three-screen design review: a designer's reason, an evidence checker's selected datum and concern, then an agreed response. Two learners can pass the controls between roles; solo play explicitly uses self-review. Contributions are saved and included in the exported report. Changing the upstream design requires a new approval.

After the high-river test, learners complete four knowledge questions with corrective feedback, connect the system path, select an actual test datum, and write a case explanation plus a follow-up responsibility. A visible checklist precedes the final Case Closed screen. The two process explanations must also be supported by evidence. Revising a design or test invalidates the relevant approvals while retaining draft text.

The final checklist shows saved evidence excerpts, topic-by-topic knowledge status and the next missing requirement. Its primary button opens the next task, resuming a missing role contribution or the relevant statement screen; it becomes the ending button only when all requirements are met. Earlier process explanations and a current high-river test remain required even when the three learning records are present. Learners can still reopen any completed record. Statement guidance asks what changed, which result supports it and what remains to be managed.

Five ending illustrations represent both districts open, pitch-supported opening, either of two partial openings, and delayed review. The engineering outcome is calculated independently from learning completion. Learners can finish the learning review even when their engineering result is delayed. Written-entry gates check completeness only: 8 words for each initial role contribution, 6 for the agreement, 12 for the explanation, and 6 for the follow-up. Scientific quality remains available for teacher or peer review; it is not automatically graded by word count.

## Model boundary

All places, credits, runoff coefficients and opening thresholds are fictional teaching settings. Each round lasts ten minutes; the drill lasts 100 minutes. The model accounts for inflow, discharge, district storage, pitch storage and overflow. Overflow leaves the model and is not counted repeatedly. Tanks and pitch water require later drainage. High river level changes the outlet limit from 32 to 16 m³ per round, holding the storm and design fixed. Branch outlet allocation is explicit; unused quota is not borrowed automatically.

The experiment's two 1,000 m² samples are separate from the whole-district scenario profiles. This is not a real flood forecast, hydraulic design tool or road-opening standard.

## Data and media

Progress is stored only in the current browser under `stormfront-english-16x9-v2`. The key is retained for compatibility; version 2 saves are upgraded to version 3 without discarding engineering choices or existing responses. Older completed cases may request missing learning evidence before they can be closed again. Different browsers or the file and HTTP versions have separate storage. A new-case dialog replaces the local save. After case closure, the report downloads a plain-text file with decisions, evidence, ten-round data, role contributions, first recorded quiz responses, attempts and the case statement. It does not send them to a server.

Illustrations were generated and edited with Recraft for this project. Rain audio is synthesized in the browser and defaults to off. SFX starts on and can be muted separately. Objectively marked process, knowledge and path responses play distinct rising/descending tones; hypotheses, designs and writing do not. The captioned teaching video is optional from the cover and prologue, uses no autoplay, and lowers the rain level while playing. Returning preserves the investigation checkpoint. It contains quiet generated ambience and no narration. There are no external runtime dependencies or analytics calls. External reference links open only when the player clicks them.

Course references: SS03.6 Scenario-based Learning; SS04.2 5E Model. Contextual reference: [Hong Kong DSD flood prevention strategy](https://www.dsd.gov.hk/others/IRTS/en/fpwc.html). Runtime: [SugarCube documentation](https://www.motoslave.net/sugarcube/2/docs/).
