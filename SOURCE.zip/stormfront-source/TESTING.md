# Local review verification

## Teaching media revision — 13 November 2026

- Added an original 42-second captioned animation on the role and limits of urban drainage. Browser metadata confirmed 960 × 540 video and successful user-initiated playback. Built-in captions, key-idea notes and native controls fit the fixed 16:9 stage without page scrolling.
- Cover and prologue entries open the video. Returning preserves the original screen and checkpoint. SFX toggling does not restart playback. Rain remains separately switchable and is lowered during the video.
- Distinct correct/incorrect tones accompany objectively marked explanation, knowledge and path responses. Media and controller tests check source selection, interruption, independent mute, safe API fallback and all three response types. Initial hypotheses and engineering trade-offs receive no correctness sound.
- README now includes a four-row learning-type/activity/evidence table and retains its quick walkthrough. The build contains 11 Twine passages, 18 illustrations and embedded media. Source distribution includes generated media, generator, module and tests.
- Browser error capture was empty during the media smoke test. Existing model and learning behavior is covered by the unchanged route/invariant suites and extended controller suite.

Verified on 7 November 2026. No upload or deployment was performed.

- JavaScript syntax checks passed for the app, narrative data and model.
- 576 legal design/placement/adjustment/allocation combinations passed the model checks. All five endings are reachable.
- Every tested route conserves water, respects tank/pitch capacity and the 12-credit budget, and produces no negative volume. Timing changes retain the full inflow volume.
- Low-river comparison overflow never exceeds the corresponding high-river result under the same design and storm.
- Browser playthrough: widened inlet → effective foothill storage → distributed tanks → negotiated pitch. Both districts pass; pitch holds 64 m³ and 6 credits remain.
- Browser playthrough: the same two pilot choices → upstream interception → extra district tanks. Both districts pass through a different, fully spent shared-budget route.
- Off-path construction was tested, diagnosed and corrected in the browser. Pitch activation was disabled before the restoration promise and enabled after it.
- Experimental feedback, camera time switching, ten-round data paging, the retained single course overview, case statement and four-question assessment were tested.
- Reload preserved the case statement and the 4/4 knowledge-check result. A downloaded English case report was read back from disk.
- Key fixed-frame screens were checked for clipped panels after layout corrections. The frame remains 16:9 and the document has no vertical page scroll.
- All gameplay text is English. The standalone file embeds 18 WebP assets and has no external script sources.

The browser automation surface permits HTTP/HTTPS pages and refused a `file://` navigation. Interactive verification therefore used the local HTTP build. The standalone offline HTML contains the same application plus an inline asset map; its direct file-protocol launch was not browser-tested. Open the delivered HTML manually in Chrome, Edge or Safari for review.

Browser storage can be restricted by browser settings; the in-scene tool row reports unavailable saving if localStorage is denied. A landscape display is recommended because the requested aspect ratio is preserved even in portrait windows.

## Scene-only interface revision

Removed the global brand header and footer captions. Tools and navigation are positioned within the 16:9 scene. Removed the cover chapter teaser and duration/cities/endings line. Deleted course pages 2–4 and their navigation. Browser checks of the home, course overview, ending, case report and journal found no clipped panels or page scrolling; no header/footer elements remain in these screens.

## Learning workflow and readability revision — 8 November 2026

- The model suite passed all 576 legal routes. The new learning suite passed completion, correction, stale-approval, legacy-save and independent engineering-ending checks.
- Controller tests ran the actual app handlers: unsupported explanations cannot advance, final tests lead to Debrief, incomplete learning cannot close a case, and complete learning can. Reapproving an upstream proposal resets the outlet investigation and removes its low-river result.
- The actual report-export handler was tested with a captured Blob. It includes role contributions, follow-up responsibility, the selected actual datum and learning completion status. Browser downloads were not used for this revision's export check.
- A complete HTTP browser playthrough used permeable paving, on-path hillside interception, further upstream interception, no final capacity addition and Balanced allocation. The high-river test produced 95.4 m³ inflow, zero overflow in both districts and 4 credits remaining; after all learning records were completed, the formal ending appeared.
- Browser checks confirmed that wrong process explanations, wrong quiz answers, a disconnected system path, a short role contribution and missing follow-up text block the relevant next action. Corrective feedback permits revision.
- Paired designer, checker and agreement entries were completed. Refresh retained the role records and the written case statement. Changing the final test requires the statement to be recorded again.
- The expanded single About page visibly maps SBL and all five 5E phases to game activities and shows the Recraft credit at the bottom.
- Main body text, options, labels, map markers, buttons and feedback were enlarged. Dense report content uses two successive screens. Key screens were checked at 1440 × 810; the final engineering cards were checked with the full pitch description unlocked. Corrected card and heading spacing retained the larger type. Final shared design, collaboration, final design, high-river results, checklist and About checks found no panel overflow or page scrolling; the frame ratio remained 16:9.
- Preview screenshots are provided in `../outputs/`. The standalone and web build were regenerated with 10 Twine passages and 18 embedded/separate WebP assets respectively. No upload or publication was performed.

Word counts check whether a contribution is present, not whether its scientific argument is correct. Teacher or peer review of the exported reasoning is still needed. Browser interaction used the HTTP build; the direct file-protocol limitation described above still applies.

## Final learning review spacing correction — 8 November 2026

The review introduction now uses its natural content height with 24 stage pixels of space before the three cards. Browser verification measured that gap, confirmed that cards and bottom controls remain clear, and found no card overflow or page scrolling. The frame remains 16:9 and the enlarged typography is unchanged. Only this screen receives the spacing rule.

## Guided learning checklist — 8 November 2026

- The learning and controller suites passed new checks for next-task routing, earlier unsupported explanations, missing role contributions, stale statement acceptance, direct writing resumption and final closure. Actual rendered summary markup contains the selected test value and saved follow-up.
- Browser testing confirmed the primary button opens the statement when a test datum is missing, then resumes the writing screen directly when only follow-up text is missing. Blank follow-up prevents recording. After a complete statement is recorded, the page shows 3/3 records and the primary button opens the engineering ending.
- A previously checked knowledge response was changed to an unsupported answer. The knowledge card became the next task; the primary button opened that question. Correcting it restored closure readiness.
- Cards display saved designer reasoning, the low-river checker datum, four knowledge-topic statuses, the current high-river evidence value and follow-up responsibility. Long excerpts are limited to two visible lines; the full records remain available through each card's button and the exported report.
- The introduction is a pale-green guidance panel with a next-step message and record count. The next card has a distinct border and text marker; completed cards have checkmarks. Cards are shorter, with aligned bottom buttons. Three concrete writing prompts appear beside the selected datum on the existing writing screen.
- Browser checks of the incomplete, knowledge-revision and ready checklists and the writing screen found no panel overflow or page scrolling. The guidance-panel-to-card gap measured 24 stage pixels, the frame remained 16:9 and bottom controls were clear. Previews are saved in `../outputs/Stormfront-Guided-Review-*.jpg` and `../outputs/Stormfront-Reasoning-Prompts-Preview.jpg`.

## Readable input states and camera spacing — 8 November 2026

- Reproduced SugarCube's default hover/focus rule changing a writing field to `rgb(51, 51, 51)` while retaining dark text. Game-scoped rules now preserve the light field background, dark text, visible caret and focus outline without altering checkbox styling.
- Browser typing checks passed for all five fields: designer proposal, checker concern, agreed response, case explanation and follow-up. Idle, mouse hover/focus and keyboard focus checks retained background `rgb(243, 244, 231)` and text `rgb(39, 60, 62)`, approximately 10.5:1 contrast. Text entry and role/report recording continued to work.
- Camera controls and captions now use sufficient content height; the reader's camera board fits its padded container. The last caption has 20 stage pixels to the camera-board bottom and 43 to the outer panel border. The description has 24 pixels to the panels. Both camera time choices remain usable; the 14:30 view was verified with no panel overflow, page scrolling or overlap with navigation. The frame remains 16:9.
- Updated offline HTML, web build and full Twee source. Previews: `../outputs/Stormfront-Readable-Input-Preview.jpg` and `../outputs/Stormfront-Camera-Spacing-Preview.jpg`. No upload or publication was performed.

## Submission release review — 8 November 2026

- Re-read both supplied assessment documents and checked topic, branch, 20-word description, four objectives, strategy application, story consequences, media and collaborative activities. `VALIDATION.md` records the coverage without predicting a grade.
- Re-ran the model, learning and controller checks. All 576 legal model routes and all learning/navigation/export checks passed.
- Followed the new English README walkthrough in a fresh browser origin using the exact self-contained publication HTML. The route reached Both lights return with 95.4 m³ inflow, zero overflow in each district and four shared credits remaining. All four knowledge responses and the demonstration statements were checked against the actual controls. The alternative pitch route's 64 m³ storage and six remaining credits were also verified against the model.
- Corrected the same description overlap on all evidence-reader pages, then checked historical-map, camera and community-interview readers. Each had 24 stage pixels before its panels and no observed overflow. Longer walkthrough role entries also exposed a context-panel overflow; adjusted margins and padding while keeping font sizes, then verified that the agreed-response screen fits.
- Checked optional rain on/off and captured no browser errors during the full walkthrough. The self-contained publication file contains all 18 embedded images, ten Twine passages and no external script sources.
