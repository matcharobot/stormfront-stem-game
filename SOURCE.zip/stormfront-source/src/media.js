/* Original media playback. Feedback sounds remain independent from rain. */
(function(root,factory){
  const api=factory(root);
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.StormMedia=api;
})(typeof window!=='undefined'?window:globalThis,function(root){
  'use strict';
  let current=null;
  function asset(name){return root.StormMediaMap&&root.StormMediaMap[name]||'media/'+name;}
  function stop(){if(current){current.pause();current=null;}}
  function answer(correct,enabled=true){
    stop();
    if(!enabled||typeof root.Audio!=='function')return false;
    try{
      current=new root.Audio(asset(correct?'answer-correct.wav':'answer-incorrect.wav'));
      current.volume=.35;
      const playing=current.play();
      if(playing&&typeof playing.catch==='function')playing.catch(()=>{});
      return true;
    }catch(_){return false;}
  }
  return {asset,answer,stop};
});
