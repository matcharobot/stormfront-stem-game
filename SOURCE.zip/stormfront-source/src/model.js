/* Original, deliberately simplified teaching model. Units: m³ per 10-minute round. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Hydro = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';
  const sum = a => a.reduce((s, n) => s + n, 0);
  const round = n => Math.round(n * 10) / 10;
  const scale = (a, k) => a.map(n => n * k);
  const shift = (a, n) => a.map((_, i) => i < n ? 0 : a[i - n]);
  const COST = {source: 8, old: 6, split: 4};
  const FINAL_COST = {none: 0, tanks: 4, timing: 0, field: 2};
  function runoff(rain, area, coefficient) { return rain / 1000 * area * coefficient; }
  function detained(a, capacity, start, rate) {
    let held = 0;
    return a.map((incoming, i) => {
      const take = Math.min(incoming, capacity - held);
      held += take;
      const release = i >= start ? Math.min(rate, held) : 0;
      held -= release;
      return incoming - take + release;
    });
  }
  function profiles(choices) {
    let plain = [12, 28, 32, 16, 4, 0, 0, 0, 0, 0];
    let hill = [0, 0, 24, 40, 32, 12, 0, 0, 0, 0];
    if (choices.baishi === 'permeable') plain = scale(plain, .65);
    if (choices.baishi === 'store') plain = detained(plain, 18, 4, 6);
    if (choices.baishi === 'inlet') plain = [28, 44, 16, 4, 0, 0, 0, 0, 0, 0];
    if (choices.placement !== 'offpath') {
      if (choices.qingling === 'intercept') hill = scale(hill, .6);
      if (choices.qingling === 'detain') hill = detained(hill, 30, 4, 10);
      if (choices.qingling === 'bypass') hill = [0, 24, 40, 32, 12, 0, 0, 0, 0, 0];
    }
    if (choices.confluence === 'source') hill = scale(hill, .55);
    return {plain, hill};
  }
  function canTime(choices) { return (choices.placement !== 'offpath' && ['intercept', 'detain'].includes(choices.qingling)) || choices.confluence === 'source'; }
  function finalAllowed(choices, flags, adjustment) {
    if (!(adjustment in FINAL_COST)) return false;
    if (12 - (COST[choices.confluence] || 0) < FINAL_COST[adjustment]) return false;
    if (adjustment === 'timing' && !canTime(choices)) return false;
    if (adjustment === 'field' && !(flags.fieldAgreement && flags.restorePromise)) return false;
    return true;
  }
  function simulate(choices = {}, adjustment = 'none', priority = 'balanced', water = 'high') {
    let {plain, hill} = profiles(choices);
    if (adjustment === 'timing' && canTime(choices)) hill = shift(hill, 2);
    const baseCaps = choices.confluence === 'old' ? [50, 12] : choices.confluence === 'split' ? [24, 24] : [18, 18];
    const caps = baseCaps.map(n => n + (adjustment === 'tanks' ? 20 : 0));
    const allocation = priority === 'old' ? [.78, .22] : priority === 'corridor' ? [.25, .75] : [.55, .45];
    const holding = [0, 0], overflow = [0, 0];
    let field = 0, drained = 0;
    const rows = plain.map((p, t) => {
      const h = hill[t], incoming = p + h;
      const outlet = water === 'low' ? 32 : 16;
      const capture = adjustment === 'field' ? Math.min(Math.max(0, incoming - 20), 64 - field) : 0;
      field += capture;
      const after = incoming - capture;
      let used = 0;
      const spills = [0, 0];
      [.55, .45].forEach((share, j) => {
        const load = holding[j] + after * share;
        const out = Math.min(load, outlet * allocation[j]);
        used += out;
        spills[j] = Math.max(0, load - out - caps[j]);
        overflow[j] += spills[j];
        holding[j] = Math.min(caps[j], load - out);
      });
      drained += used;
      return {minute: (t + 1) * 10, plain: p, hill: h, incoming, outlet, drained: used, oldHeld: holding[0], corridorHeld: holding[1], oldSpill: spills[0], corridorSpill: spills[1], field};
    });
    const total = sum(plain) + sum(hill);
    const firstSpill = rows.find(r => r.oldSpill + r.corridorSpill > .001);
    const pass = overflow.map(n => n <= 6 + 1e-8);
    const ending = pass[0] && pass[1] ? (adjustment === 'field' ? 'field' : 'both') : pass[0] ? 'old' : pass[1] ? 'corridor' : 'delay';
    return {rows, plain, hill, total, peak: Math.max(...rows.map(r => r.incoming)), holding, caps, overflow, drained, field, pass, ending, firstSpill: firstSpill ? firstSpill.minute : null,
      balanceError: total - drained - field - sum(holding) - sum(overflow), cost: COST[choices.confluence] || 0, finalCost: FINAL_COST[adjustment], budget: 12 - (COST[choices.confluence] || 0) - FINAL_COST[adjustment], water, adjustment, priority};
  }
  return {sum, round, runoff, profiles, simulate, canTime, finalAllowed, COST, FINAL_COST};
});
