/* Learning evidence is separate from the hydraulic outcome. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.StormLearning=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';
  const questions=[
    {id:'control',q:'Which is a fair comparison of grass and asphalt?',options:['Same rain, area and duration; change only the surface.','Change the rain and the surface together.','Compare watermarks from two different storms.'],correct:0,why:'Holding rain, area and duration constant isolates the surface effect.'},
    {id:'travel',q:'A bypass clears the foothill sooner. What must you check next?',options:['Local drainage proves the whole catchment is safe.','Whether its peak overlaps another flow downstream.','Only whether the new channel is wider.'],correct:1,why:'Local relief can shift the timing and increase downstream peak overlap.'},
    {id:'storage',q:'What does water in a tank at minute 100 represent?',options:['Water removed from the water cycle.','Water already discharged into the river.','Water still stored, needing a later drainage plan.'],correct:2,why:'Storage changes timing. The retained volume remains in the water balance.'},
    {id:'transfer',q:'A different city floods after expanding its pipes. What is the best review?',options:['Check upstream runoff, arrival timing and downstream water level.','Judge safety from pipe diameter alone.','Copy this design without checking local conditions.'],correct:0,why:'A system explanation connects inflow, timing, storage and the outlet boundary.'}
  ];
  function words(text){return String(text||'').trim().split(/\s+/).filter(Boolean).length;}
  function upgrade(r){
    const legacy=r.version!==3;
    r.version=3;r.quiz=r.quiz||{};r.answers=r.answers||{};
    r.quizAttempts=r.quizAttempts||{};r.quizFirst=r.quizFirst||{};
    r.council=Object.assign({step:0,mode:'',proposal:'',metric:'',challenge:'',agreement:'',approvedFor:null},r.council||{});
    r.reviewStep=r.reviewStep||'quiz';r.followup=r.followup||'';
    r.reportMetric=r.reportMetric||'';r.reportAcceptedFor=r.reportAcceptedFor||null;
    r.learningClosedFor=r.learningClosedFor||null;r.reportPage=r.reportPage||0;
    if(legacy){r.reviewStep='summary';r.quizIndex=firstMissingQuestion(r);}
    return r;
  }
  function designKey(r){const c=r.choices||{};return JSON.stringify([c.baishi,c.qingling,c.placement,c.confluence]);}
  function testKey(r){const s=r.sim;if(!s||s.water!=='high'||r.simChapter!=='review')return null;return JSON.stringify([designKey(r),r.adjustment,r.priority,s.total,s.overflow,s.holding,s.field]);}
  function explanationCorrect(r,key){return (r.answers||{})[key]===(key==='baishi'?'surface':'travel');}
  function score(r){return questions.filter(q=>(r.quiz||{})[q.id]===q.correct).length;}
  function quizComplete(r){return score(r)===questions.length;}
  function firstMissingQuestion(r){const i=questions.findIndex(q=>(r.quiz||{})[q.id]!==q.correct);return i<0?0:i;}
  function councilStepReady(r,step){const c=r.council||{};
    if(step===0)return ['pair','solo'].includes(c.mode)&&words(c.proposal)>=8;
    if(step===1)return ['peak','budget','overflow'].includes(c.metric)&&words(c.challenge)>=8;
    return words(c.agreement)>=6;
  }
  function councilDraftReady(r){return [0,1,2].every(i=>councilStepReady(r,i));}
  function councilComplete(r){return !!r.choices?.confluence&&councilDraftReady(r)&&r.council.approvedFor===designKey(r);}
  function reportChecks(r){return {
    simulation:!!testKey(r),
    path:(r.answers||{}).path==='connected',
    metric:['inflow','old','walk','held'].includes(r.reportMetric),
    explanation:words(r.explanation)>=12,
    followup:words(r.followup)>=6
  };}
  function reportDraftReady(r){return Object.values(reportChecks(r)).every(Boolean);}
  function reportComplete(r){const key=testKey(r);return !!key&&reportDraftReady(r)&&r.reportAcceptedFor===key;}
  function canComplete(r){return !!testKey(r)&&explanationCorrect(r,'baishi')&&explanationCorrect(r,'qingling')&&quizComplete(r)&&councilComplete(r)&&reportComplete(r);}
  function caseClosed(r){return canComplete(r)&&r.learningClosedFor===testKey(r);}
  function nextCouncilStep(r){return !councilStepReady(r,0)?0:!councilStepReady(r,1)?1:2;}
  function reviewGuide(r){
    const c=r.council||{},checks=reportChecks(r),complete={council:councilComplete(r),quiz:quizComplete(r),report:reportComplete(r)};
    const councilNeed=complete.council?'Reason, evidence challenge and joint response saved.':
      !['pair','solo'].includes(c.mode)?'Choose paired review or solo self-review.':
      words(c.proposal)<8?'Explain the reason for your design.':
      !['peak','budget','overflow'].includes(c.metric)?'Select a datum for the evidence check.':
      words(c.challenge)<8?'Record the evidence checker’s question.':
      words(c.agreement)<6?'Record the agreed response and next action.':'Confirm the review for your current design.';
    const reportNeed=complete.report?'Path, datum, explanation and follow-up recorded.':
      !checks.simulation?'Run the current high-river test first.':
      !checks.path?'Connect the upstream and downstream flow path.':
      !checks.metric?'Attach a value from your current test.':
      !checks.explanation?'Explain how a design decision produced this result.':
      !checks.followup?'Explain a cost, remaining risk or follow-up responsibility.':'Record the statement for your current test.';
    let next;
    if(!checks.simulation)next={key:'test',action:'return-test',label:'Continue: Run the storm test',hint:'A current high-river test is needed before you can close the case.'};
    else if(!explanationCorrect(r,'baishi'))next={key:'surface',action:'recheck-explanation',id:'baishi',label:'Continue: Recheck surfaces',hint:'Use the controlled experiment to revise your surface explanation.'};
    else if(!explanationCorrect(r,'qingling'))next={key:'travel',action:'recheck-explanation',id:'qingling',label:'Continue: Recheck travel time',hint:'Use the camera record to revise your travel-time explanation.'};
    else if(!complete.council)next={key:'council',action:'review-council',label:'Continue: Complete the role review',hint:councilNeed};
    else if(!complete.quiz)next={key:'quiz',action:'open-quiz',label:'Continue: Check your understanding',hint:'Revisit the next unsupported response and use its feedback.'};
    else if(!complete.report)next={key:'report',action:'continue-report',label:'Continue: Complete the statement',hint:reportNeed};
    else next={key:'close',action:'complete-case',label:'Close the case & reveal the ending',hint:'All learning records are complete. You can now reveal your engineering ending.'};
    return {complete,count:Object.values(complete).filter(Boolean).length,councilNeed,reportNeed,next};
  }
  return {questions,words,upgrade,designKey,testKey,explanationCorrect,score,quizComplete,firstMissingQuestion,councilStepReady,councilDraftReady,councilComplete,reportChecks,reportDraftReady,reportComplete,canComplete,caseClosed,nextCouncilStep,reviewGuide};
});
