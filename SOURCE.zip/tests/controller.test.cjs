'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const H=require('../src/model.js'),L=require('../src/learning.js');
const d={window:{}};vm.runInNewContext(fs.readFileSync(require.resolve('../src/data.js'),'utf8'),d);
let capturedBlob,downloadName,navigation,renderEnabled=false;
const rendered={innerHTML:""};
const listeners={};
const r=L.upgrade({version:3,choices:{baishi:'permeable',qingling:'intercept',placement:'onpath',confluence:'source'},answers:{baishi:'rain',qingling:'travel'},quiz:{},phase:{baishi:'explain'},adjustment:'none',priority:'balanced',simChapter:'review',flags:{},evidence:[],lab:{rain:30,done:true}});r.sim=H.simulate(r.choices);
const context={window:{StormData:d.window.StormData,Hydro:H,StormLearning:L,addEventListener(){}},State:{variables:{run:r},passage:'Baishi'},Config:{history:{},passages:{},saves:{}},Engine:{play(p){navigation=p;}},localStorage:{getItem(){return null;},setItem(){}},document:{addEventListener(k,v){listeners[k]=v;},getElementById(){return null;},querySelectorAll(){return renderEnabled?[rendered]:[];},documentElement:{style:{setProperty(){}}},createElement(){return {click(){downloadName=this.download;}};}},$:()=>({on(){}}),setTimeout:()=>1,clearTimeout(){},Blob,URL:{createObjectURL(b){capturedBlob=b;return 'blob:local-test';},revokeObjectURL(){}},innerWidth:1440,innerHeight:810};
vm.runInNewContext(fs.readFileSync(require.resolve('../src/app.js'),'utf8'),context);
function click(action,id){listeners.click({target:{closest(){return {disabled:false,dataset:{action,id}};}}});}
click('design');assert.equal(r.phase.baishi,'explain','an incorrect process explanation must not advance');r.answers.baishi='surface';click('design');assert.equal(r.phase.baishi,'design');
context.State.passage='Review';click('finish');assert.equal(navigation,'Debrief','the storm test leads to learning review, not the ending');navigation=null;click('complete-case');assert.equal(navigation,null);
r.council={step:2,mode:'pair',proposal:'We intercept upstream runoff before it reaches the shared city system.',metric:'peak',challenge:'What happens if the outlet capacity falls below this combined inflow peak?',agreement:'Keep this plan and test the current river condition.',approvedFor:L.designKey(r)};
L.questions.forEach(q=>r.quiz[q.id]=q.correct);r.answers.path='connected';r.reportMetric='inflow';r.explanation='The upstream changes reduce total inflow to the constrained outlet and keep both city districts within the target.';r.followup='Reserve the remaining credits for future inspection and maintenance.';r.reportAcceptedFor=L.testKey(r);
click('complete-case');assert.equal(navigation,'Ending');assert.equal(L.caseClosed(r),true);context.State.passage='Ending';click('export');assert.equal(downloadName,'Stormfront-Case-Report.txt');
context.State.passage='Confluence';r.phase.review='trial';r.sim=H.simulate(r.choices,'none','balanced','low');r.simChapter='confluence';r.councilReturn='Review';click('approve-council');assert.equal(navigation,'Review');assert.equal(r.phase.review,'survey','reapproving an upstream design starts a fresh outlet investigation');assert.equal(r.sim,null,'a low-river proposal result must not appear as a high-river final result');assert.equal(r.reportAcceptedFor,null);
capturedBlob.text().then(text=>{assert.ok(text.includes('Mode: Paired review (reported)'));assert.ok(text.includes(r.council.challenge));assert.ok(text.includes(r.followup));assert.ok(text.includes('Learning review complete: true'));assert.ok(text.includes('Chosen final datum: Total inflow / 95.4 m³'));
// Exercise the real primary button across incomplete, resumed and ready states.
r.sim=H.simulate(r.choices);r.simChapter='review';context.State.passage='Debrief';r.reviewStep='summary';
r.answers.baishi='rain';click('review-continue');assert.equal(navigation,'Baishi');assert.equal(r.explanationReturn,'Debrief');
r.answers.baishi='surface';r.answers.qingling='stop';context.State.passage='Debrief';click('review-continue');assert.equal(navigation,'Qingling');
r.answers.qingling='travel';r.council.challenge='';context.State.passage='Debrief';click('review-continue');assert.equal(navigation,'Confluence');assert.equal(r.council.step,1);
r.council.challenge='Will a lower outlet capacity overload the storage under the current test?';r.council.approvedFor=L.designKey(r);r.quiz.travel=0;context.State.passage='Debrief';click('review-continue');assert.equal(r.reviewStep,'quiz');assert.equal(r.quizIndex,1);
r.quiz.travel=1;r.answers.path='connected';r.reportMetric='inflow';r.followup='';r.reportAcceptedFor=null;context.State.passage='Debrief';click('review-continue');assert.equal(r.reviewStep,'report');assert.equal(r.reportPage,1,'resume the missing writing without repeating path selection');
r.followup='Reserve the remaining credits for future inspection and maintenance.';r.reportAcceptedFor=L.testKey(r);renderEnabled=true;context.State.passage='Debrief';click('review-summary');assert.ok(rendered.innerHTML.includes('Total inflow · 95.4 m³'));assert.ok(rendered.innerHTML.includes(r.followup));assert.ok(rendered.innerHTML.includes('Close the case &amp; reveal the ending'));assert.ok(!rendered.innerHTML.includes('data-action="review-continue" disabled'));
click('review-continue');assert.equal(navigation,'Ending');assert.equal(L.caseClosed(r),true);
console.log('PASS: app gates, guided next steps, saved-evidence summaries, resumed writing, final closure and report export.');
}).catch(e=>{console.error(e);process.exitCode=1;});
